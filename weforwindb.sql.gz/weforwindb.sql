-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 14, 2021 at 01:21 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `weforwindb`
--

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

CREATE TABLE `blogs` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `tag` varchar(255) DEFAULT NULL,
  `bin` int(11) NOT NULL DEFAULT 0,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` (`id`, `title`, `author`, `content`, `tag`, `bin`, `date`) VALUES
(1, 'How to create blog using PHP and MYSQL database?', 'sandeep', '                                        Maecenas et dolor feugiat, vulputate libero nec, imperdiet justo. Phasellus consectetur sit amet justo in mollis. Pellentesque auctor mollis consectetur. Etiam odio odio, pulvinar non lorem sed, volutpat lobortis magna. Praesent a nunc ac justo efficitur convallis. Ut blandit, lacus eget faucibus accumsan, mauris orci tincidunt mauris, sed iaculis magna libero non massa. Nulla consectetur est nec arcu efficitur interdum a sed turpis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla mattis hendrerit vulputate.\r\n\r\nNam ultricies velit vel sem sagittis commodo non non risus. Suspendisse congue, turpis euismod efficitur scelerisque, est est euismod magna, in dictum est tellus eu mi. Proin accumsan posuere eros eu varius. Etiam non libero lobortis, scelerisque sapien vel, blandit nisi. Sed pretium, justo ut maximus semper, libero purus posuere justo, non posuere sem libero ut nisi. Mauris elementum felis eget ante consectetur pulvinar. Ut finibus eu eros ac eleifend. Ut eros leo, porttitor quis egestas vel, aliquet fringilla odio. Mauris consectetur ut justo vel sollicitudin. Quisque faucibus, tortor ac luctus facilisis, sapien est scelerisque turpis, sed mattis erat nisl convallis orci.\r\n\r\nSed lacinia dapibus mauris, vitae iaculis ligula finibus ut. Mauris quam quam, cursus at nibh sed, varius lacinia lorem. Aenean aliquam ex eget tellus consequat feugiat. Phasellus auctor urna purus, non tincidunt elit euismod eu. Nam augue orci, suscipit ac dapibus et, pretium ac neque. Cras neque mauris, congue ut urna ac, eleifend vulputate massa. Quisque pulvinar egestas maximus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Phasellus imperdiet augue id aliquet tempus. Nulla vitae porta risus, eget pellentesque mi. Quisque rutrum eu orci vulputate lacinia. In ut dui eget leo pellentesque tincidunt. Donec venenatis, risus gravida blandit pharetra, magna tortor vulputate lorem, sit amet pretium urna nibh sed neque. Sed vel consectetur est, eu interdum odio.                                        ', 'dolor', 0, '2021-08-15 09:49:35'),
(2, 'Where can I get some?', 'admin01', '                                        There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which do not look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there is nott anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.\r\n\r\n                                        ', 'lorem', 0, '2021-10-03 12:36:16'),
(3, 'Where does it come from?', 'admin', '                                        Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.\r\n\r\n                                        ', 'gg', 0, '2021-11-06 08:25:59');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `fullname`, `email`, `password`, `date`) VALUES
(1, 'super admin', 'weforwin@admin.com', 'Weforwin2021', '2021-11-14 10:20:02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blogs`
--
ALTER TABLE `blogs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blogs`
--
ALTER TABLE `blogs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
