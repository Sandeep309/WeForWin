-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 03, 2021 at 02:46 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `weforwindb`
--

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

CREATE TABLE `blogs` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `tag` varchar(255) DEFAULT NULL,
  `bin` int(11) NOT NULL DEFAULT 0,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` (`id`, `title`, `author`, `content`, `tag`, `bin`, `date`) VALUES
(4, 'Man must explore, and this is exploration at its greatest ', 'admin', 'Pellentesque in viverra dolor. Phasellus eget erat sit amet urna pulvinar vehicula. Fusce hendrerit nisi sed elit accumsan tincidunt. Quisque est urna, porta ac erat quis, finibus elementum nisi. Duis tincidunt ligula a quam posuere, sit amet ullamcorper dolor imperdiet. Donec tempus, urna cursus rutrum eleifend, diam lectus lacinia enim, in posuere ex risus quis risus. Nulla facilisi. Nulla pulvinar dictum ligula quis semper. Maecenas fringilla risus felis, eu condimentum sapien fringilla sed. Sed vitae enim sed quam maximus tristique vitae vel erat. Maecenas turpis neque, tincidunt non mauris a, commodo pharetra libero. Duis finibus pulvinar justo vel dapibus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.\r\n\r\nMauris ex ante, feugiat eget pulvinar vel, dignissim ut erat. Nunc venenatis nisl et metus mattis blandit. Ut non lacus ullamcorper, tincidunt magna sit amet, congue nisl. Phasellus at porta felis. Integer tempor arcu sit amet ex euismod, nec pretium arcu eleifend. Fusce eget nulla quis ante pharetra placerat. Etiam et mi convallis, commodo enim ut, suscipit quam. Aliquam justo orci, lobortis nec maximus quis, lobortis a augue. Aenean porta dolor ac justo sollicitudin lobortis. Nam arcu libero, aliquet sit amet egestas ac, suscipit in nulla. Pellentesque fermentum laoreet velit sed gravida. Vivamus et ante porta, fermentum lorem quis, scelerisque eros.\r\n\r\nCras venenatis sit amet mauris aliquam pharetra. Etiam sodales erat in ex ornare, convallis elementum magna finibus. Nam dapibus volutpat viverra. Fusce feugiat, justo sed convallis elementum, nisi nisl placerat sapien, et ornare diam ligula non mi. Suspendisse vestibulum purus enim, eu iaculis mi condimentum sit amet. Cras sed ullamcorper lectus. Praesent aliquam leo sem, at consequat neque sodales sit amet. Nullam bibendum nisi tortor, in sollicitudin neque vulputate eu. Vivamus ligula nulla, facilisis quis consequat non, rutrum eget enim. Nullam in aliquet ligula. Integer faucibus nunc et auctor interdum. Etiam molestie, dui vitae cursus elementum, felis ante dapibus massa, vel pellentesque nibh libero a tellus. Sed at lectus in urna tristique varius. Suspendisse vitae magna ante. Quisque convallis eros at vestibulum ullamcorper.\r\n\r\nNunc commodo condimentum turpis sit amet mollis. Pellentesque varius eleifend quam, sit amet congue urna viverra non. Sed suscipit justo et enim rhoncus, facilisis auctor enim porta. Fusce dapibus neque magna. Suspendisse potenti. Donec viverra sollicitudin ex, quis iaculis purus iaculis egestas. Sed quis consequat eros, vel luctus est. Sed interdum blandit fermentum. Nunc luctus, massa viverra lacinia sodales, libero nunc aliquet dui, ullamcorper porta ex neque nec orci. Nunc blandit, sem vitae finibus consequat, ipsum lacus pulvinar lorem, sit amet tincidunt augue dui in orci. Etiam ultricies sodales dictum. Aenean dapibus imperdiet arcu placerat posuere. Proin tristique venenatis orci, in commodo lorem porta id.\r\n\r\nEtiam ullamcorper libero nec dolor accumsan ullamcorper. Maecenas vitae imperdiet felis, eu egestas nulla. Maecenas sit amet ornare turpis, id bibendum mi. Nullam eu dolor dapibus, congue leo non, tempor ante. Ut at erat a erat pharetra tristique sit amet at orci. Phasellus quam erat, porta non ex sed, vestibulum ullamcorper lorem. Mauris nisi mi, ornare at odio vel, sodales sodales elit. Quisque et nisl a nulla consequat ullamcorper vel eget ante. Nulla lacus libero, tempor sit amet ultricies sit amet, blandit a libero. Vivamus vitae lacus sed quam luctus porta. Fusce ultrices commodo neque hendrerit volutpat. Aenean risus leo, malesuada in elit auctor, porta egestas erat. Morbi bibendum, elit ac fermentum dignissim, dui risus molestie ex, non fringilla felis ligula eget dolor. Aliquam erat volutpat. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Morbi id nunc vel sapien vestibulum porta.\r\n\r\nSuspendisse potenti. Morbi vehicula dapibus tellus. Fusce tempus mauris vitae ipsum hendrerit fermentum. Nullam finibus, diam quis finibus imperdiet, tellus ante rhoncus massa, non eleifend arcu ex id orci. Nullam lectus lectus, aliquet ac sem in, tristique sodales quam. Aenean non ligula accumsan, iaculis ligula ac, venenatis lectus. Aenean bibendum vitae magna ut interdum. Ut gravida varius risus non consequat. Curabitur efficitur mauris posuere massa iaculis, sed sodales velit condimentum. Vestibulum blandit nunc eget sem laoreet dapibus.\r\n\r\nNulla vel purus vitae enim viverra lobortis a eu nisi. Etiam non vulputate diam, ullamcorper dapibus mi. Fusce sem nisi, imperdiet vel erat eu, convallis sollicitudin diam. Interdum et malesuada fames ac ante ipsum primis in faucibus. Duis quis enim mauris. Mauris blandit felis at tortor feugiat, et sagittis ipsum elementum. Vestibulum sodales suscipit nibh, sed lacinia mi imperdiet vel. In hac habitasse platea dictumst. Nam malesuada iaculis nisl id auctor. Curabitur quis orci urna. Cras nisi metus, ornare eu mattis venenatis, rutrum ac ante. Mauris accumsan augue neque, at finibus eros facilisis in.\r\n\r\nMaecenas et dolor feugiat, vulputate libero nec, imperdiet justo. Phasellus consectetur sit amet justo in mollis. Pellentesque auctor mollis consectetur. Etiam odio odio, pulvinar non lorem sed, volutpat lobortis magna. Praesent a nunc ac justo efficitur convallis. Ut blandit, lacus eget faucibus accumsan, mauris orci tincidunt mauris, sed iaculis magna libero non massa. Nulla consectetur est nec arcu efficitur interdum a sed turpis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla mattis hendrerit vulputate.\r\n\r\nNam ultricies velit vel sem sagittis commodo non non risus. Suspendisse congue, turpis euismod efficitur scelerisque, est est euismod magna, in dictum est tellus eu mi. Proin accumsan posuere eros eu varius. Etiam non libero lobortis, scelerisque sapien vel, blandit nisi. Sed pretium, justo ut maximus semper, libero purus posuere justo, non posuere sem libero ut nisi. Mauris elementum felis eget ante consectetur pulvinar. Ut finibus eu eros ac eleifend. Ut eros leo, porttitor quis egestas vel, aliquet fringilla odio. Mauris consectetur ut justo vel sollicitudin. Quisque faucibus, tortor ac luctus facilisis, sapien est scelerisque turpis, sed mattis erat nisl convallis orci.', 'space', 0, '2021-08-15 09:47:37'),
(5, 'How to create blog using PHP and MYSQL database?', 'sandeep', 'Maecenas et dolor feugiat, vulputate libero nec, imperdiet justo. Phasellus consectetur sit amet justo in mollis. Pellentesque auctor mollis consectetur. Etiam odio odio, pulvinar non lorem sed, volutpat lobortis magna. Praesent a nunc ac justo efficitur convallis. Ut blandit, lacus eget faucibus accumsan, mauris orci tincidunt mauris, sed iaculis magna libero non massa. Nulla consectetur est nec arcu efficitur interdum a sed turpis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla mattis hendrerit vulputate.\r\n\r\nNam ultricies velit vel sem sagittis commodo non non risus. Suspendisse congue, turpis euismod efficitur scelerisque, est est euismod magna, in dictum est tellus eu mi. Proin accumsan posuere eros eu varius. Etiam non libero lobortis, scelerisque sapien vel, blandit nisi. Sed pretium, justo ut maximus semper, libero purus posuere justo, non posuere sem libero ut nisi. Mauris elementum felis eget ante consectetur pulvinar. Ut finibus eu eros ac eleifend. Ut eros leo, porttitor quis egestas vel, aliquet fringilla odio. Mauris consectetur ut justo vel sollicitudin. Quisque faucibus, tortor ac luctus facilisis, sapien est scelerisque turpis, sed mattis erat nisl convallis orci.\r\n\r\nSed lacinia dapibus mauris, vitae iaculis ligula finibus ut. Mauris quam quam, cursus at nibh sed, varius lacinia lorem. Aenean aliquam ex eget tellus consequat feugiat. Phasellus auctor urna purus, non tincidunt elit euismod eu. Nam augue orci, suscipit ac dapibus et, pretium ac neque. Cras neque mauris, congue ut urna ac, eleifend vulputate massa. Quisque pulvinar egestas maximus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Phasellus imperdiet augue id aliquet tempus. Nulla vitae porta risus, eget pellentesque mi. Quisque rutrum eu orci vulputate lacinia. In ut dui eget leo pellentesque tincidunt. Donec venenatis, risus gravida blandit pharetra, magna tortor vulputate lorem, sit amet pretium urna nibh sed neque. Sed vel consectetur est, eu interdum odio.', '', 0, '2021-08-15 09:49:35'),
(9, 'Why do we use it?', 'sandeep', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using Content here, content here, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for lorem ipsum will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).', 'lorem', 0, '2021-10-03 11:04:01'),
(10, 'Where can I get some?', 'kk', 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which do not look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there is nott anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.\r\n\r\n', 'lorem', 0, '2021-10-03 12:36:16');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blogs`
--
ALTER TABLE `blogs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blogs`
--
ALTER TABLE `blogs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
